$(document).ready(function() {
    window.addEventListener('dfMessengerLoaded', function (event) {
    $r1 = document.querySelector("df-messenger");
    $r2 = $r1.shadowRoot.querySelector("df-messenger-chat");
    $r3 = $r2.shadowRoot.querySelector("df-messenger-user-input"); //for other mods
    $r4 = $r2.shadowRoot.querySelector("df-messenger-user-input"); //for other mods
    console.log ($r1, $r2, $r3);
});
});
$(document).ready(function(){
    const dfMessenger = document.querySelector('df-messenger');
    console.log (dfMessenger)
    dfMessenger.addEventListener('df-response-received', function (event) {
        console.log(event);
        var texto2 = event.detail.response.queryResult.fulfillmentMessages[0].text.text[0];
        console.log(texto2)
        var texto2 = event.detail.response.queryResult.fulfillmentMessages.l;
        console.log(texto2)

        var texto = event.detail.response.queryResult.queryText
        console.log(texto);
  // Handle event
  
})
console.log (dfMessenger)
const dfMessenger2 = document.querySelector('df-messenger');
    dfMessenger2.addEventListener('df-response-response: detectIntentResponse', function (event) {
    console.log("hola"+event);
// Handle event

})
})
$(document).ready(function(){
//     const button = document.getElementById('widgetIcon');
//     console.log(button);

//     button.addEventListener('click', function handleClick() {
//         const button2 = document.getElementById('sendIconButton');

//         button2.addEventListener('click', function handleClick() {
//           console.log('element clickedssss');
//     });
//      });
//     var val = document.getElementById("idchat").getAttribute("session-id");  
//     $.getJSON('https://dialogflow.cloud.google.com/v1/cx/integrations/messenger/webhook/b19c8cbd-5ddc-4764-8ddb-00cda9cc93f1/sessions/dfMessenger-24368568', function(data) {
//     console.log(data);
// });
//   });


//   window.onload = function(){ 
//     const button = document.getElementById('widgetIcon');

//     button.addEventListener('click', function handleClick() {
//         const button2 = document.getElementById('sendIconButton');

//         button2.addEventListener('click', function handleClick() {
//           console.log('element clickedssss');
//     });
//      });
setTimeout(function(){
    console.log("Executed after 1 second");
    const sessionId = document.getElementById('idchat').getAttribute('session-id');
   console.log(sessionId);
    const button2 = document.getElementById('--df-messenger-button');
     console.log(button2)
     const asd = document.getElementById( 'idchat' ).getElementsByTagName('*');
     console.log(asd);
     var elements = document.getElementsByTagName("body")[0].parentNode.childNodes;
     console.log(elements);
//     button.addEventListener('click', function handleClick() {
//             console.log("hola")
//     })

  populate(sessionId);
   $.getJSON('https://dialogflow.cloud.google.com/v1/cx/integrations/messenger/webhook/b19c8cbd-5ddc-4764-8ddb-00cda9cc93f1/sessions/'+sessionId, function(data) {
    console.log(data);
});

}, 1000);
   

})
const button = document.getElementById('hopebutton');
     button.addEventListener('click', function handleClick() {
        
        const sessionId = document.getElementById('idchat').getAttribute('session-id');
        console.log(sessionId);
        populate(sessionId);
})

async function populate(sessionId) {


    cadena={
        
            "queryInput": {
              "text": {
                "text": "hola"
              },
              "languageCode": "en"
            },
            "queryParams": {
              "timeZone": "America/Los_Angeles"
            }
          
    }

    
    $.ajax({
        type: "POST",
        url: "https://global-dialogflow.googleapis.com/v3/projects/proyectosamantha/locations/global/agents/samantha1/sessions/"+sessionId+":detectIntent",
        data: cadena,
        dataType:'json',
        success: function (r) {
                    if (r == 1) {
                        console.log(r);
                        
                    } else {
                        console.log("hola2");
                    }
                },
        
    });
  }
